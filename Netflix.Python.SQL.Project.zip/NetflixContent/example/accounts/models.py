from django.contrib.auth.models import User
from django.db import models


class list_show(models.Model):
    title = models.CharField('Title', max_length=100)
    release_year = models.DateField('Year')
    rating = models.CharField('Rating', max_length=100)
    listed_in = models.CharField('Listed', max_length=100)
    description = models.CharField('Description', max_length=700)
    image_show = models.ImageField(null=True, blank=True, upload_to="images/")

    def __str__(self):
        return self.title


class list_movie(models.Model):

    title = models.CharField('Title', max_length=100)
    release_year = models.DateField('Year')
    rating = models.CharField('Rating', max_length=100)
    listed_in = models.CharField('Listed', max_length=100)
    description = models.CharField('Description', max_length=700)
    image_movie = models.ImageField(null=True, blank=True, upload_to="images/")

    def __str__(self):
        return self.title

class list_other(models.Model):
    title = models.CharField('Title', max_length=100)
    release_year = models.DateField('Year')
    rating = models.CharField('Rating', max_length=100)
    listed_in = models.CharField('Listed', max_length=100)
    description = models.CharField('Description', max_length=700)
    image_other = models.ImageField(null=True, blank=True, upload_to="images/")

    def __str__(self):
        return self.title