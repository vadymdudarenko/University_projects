from django.urls import path
from . import views


urlpatterns = [
    path('',views.index,name="home"),
    path('accounts/sign_up/',views.sign_up,name="sign-up"),
    path('accounts/logout/',views.logout, name='logout'),
    path('accounts/list_movie/',views.LIST, name='list-movie'),
    path('accounts/list_show/',views.SHOW, name='list-show'),
    path('accounts/link/',views.link, name='link'),
    path('accounts/list/<list_movie_id>',views.list, name='list'),
    path('accounts/list_other/',views.other, name='list-other'),
    path('search_venues', views.search_venues, name='search-venues'),

]