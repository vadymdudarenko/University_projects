from django.contrib import admin
from .models import list_movie
from .models import list_show
from .models import list_other
# Register your models here.

admin.site.register(list_movie)
admin.site.register(list_show)
admin.site.register(list_other)