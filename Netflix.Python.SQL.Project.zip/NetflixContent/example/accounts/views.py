from django.contrib import auth
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.shortcuts import render
from .models import list_movie
from .models import list_show
from .models import list_other

@login_required
def index(request):
    return render(request,'accounts/listother.html')
def sign_up(request):
    context = {}
    form = UserCreationForm(request.POST or None)
    if request.method == "POST":
        if form.is_valid():
            user = form.save()
            login(request,user)
            return render(request,'accounts/listother.html')
    context['form']=form
    return render(request,'registration/sign_up.html',context)

def logout(request):
    auth.logout(request)
    return render(request,'accounts/login.html')


def LIST(request):
    movielist = list_movie.objects.all()
    return render (request, 'accounts/listmovie.html',
                   {'movielist':movielist})
def SHOW(request):
    showlist = list_show.objects.all()
    return render(request, 'accounts/listshow.html',
                   {'showlist':showlist})

def other(request):
    return render(request, 'accounts/listother.html',
                   {})

def link(request):
    spisok = list_movie.objects.all()
    return render(request, 'accounts/links.html',
                   {'spisok':spisok } )

def list(request,list_movie_id):
    train= list_movie.objects.get(pk = list_movie_id)

    return render(request, 'accounts/list.html',
                   {'train':train} )


def search_venues(request):
    if request.method == "POST":
        searched = request.POST['searched']
        venues = list_movie.objects.filter(title__contains=searched)

        return render(request,
                      'accounts/search_venues.html',
                      {'searched': searched,
                       'venues': venues})
    else:
        return render(request,
                      'accounts/search_venues.html',
                      {})