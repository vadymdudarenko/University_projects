
import sqlite3

def printAll(listOfResultsA):
    for item in listOfResultsA:
        print(item)

conn = sqlite3.connect('db.sqlite3')

c = conn.cursor()

c.execute("Select title from name")
print("\nPresent all title in name table:")
printAll(c.fetchall())

c.execute("Select * from decription")
print("\nPresent all data in description table:")
printAll(c.fetchall())

c.execute("Select * from country")
print("\nPresent all countries in table")
printAll(c.fetchall())

print("\nPrint join results for three tables. Output table (title, country, description) :")
c.execute("SELECT title, country, description FROM name join country on name.c_id = country.c_id \
        join decription on decription.show_id = name.show_id where country = 'United States'")

#GROUP BY
print("\n table records grouped by type and count numeber of different types. Output (title, duration, desciption, type):")
c.execute("SELECT title, duration, description, type1, count(*) from name join type on name.t_id = type.t_id join decription on decription.show_id = name.show_id group by type.type1;")
#get all results,assign them to the list,fecthall() returns empty list if no results
printAll(c.fetchall())

#GROUP BY+agregate functions
print("\n  statistics for movies release date grouped by country.  Output( max_release_year,min_release_year,count):")
c.execute("SELECT MAX(release_year), MIN(release_year),COUNT(*), MAX(data_added) FROM name join country on name.c_id=country.c_id GROUP BY country = 'United States' ")
printAll(c.fetchall())

#add extra index on one column
print("\nwe add extra index on column 'show_id' in name table")
c.execute("CREATE INDEX idx_name ON name (show_id)")

#get all results,assign them to the list,fecthall() returns empty list if no results
printAll(c.fetchall())

#add extra index on one column
print("\nwe add extra index on column 'type1' in type table")
c.execute("CREATE INDEX idx_name1 ON type (type1)")

#get all results,assign them to the list,fecthall() returns empty list if no results
printAll(c.fetchall())

#add extra index on one column
print("\nwe add extra index on column 'cast' in cast table")
c.execute("CREATE INDEX idx_name2 ON cast(cast)")

#get all results,assign them to the list,fecthall() returns empty list if no results
printAll(c.fetchall())

#return students whose name starts with J'
print("\n titles which starts with 'S':")
c.execute("SELECT title, country, description FROM name join country on name.c_id = country.c_id \
        join decription on decription.show_id = name.show_id where name.title LIKE 'S%'")

#create new view
print("\nCreate new view, which contains only titles which have countries")
c.execute("CREATE VIEW VIEW1 AS SELECT title, country, description FROM name join country on name.c_id = country.c_id \
        join decription on decription.show_id = name.show_id")
#get all results,assign them to the list,fecthall() returns empty list if no results
printAll(c.fetchall())
#create trigger HP
print("Create trigger\n")
c.execute("Create trigger HP after delete on name \
    BEGIN insert into name values('101','HP','17-01-20202','2022','101','101','101','101'); END;")

#get all results,assign them to the list,fecthall() returns empty list if no results
printAll(c.fetchall())

#delete title "HP"
print("Delete student Denis Rodman from student table\n")
c.execute("Delete from name where title='HP' ")

#get all results,assign them to the list,fecthall() returns empty list if no results
printAll(c.fetchall())

#get all results,assign them to the list,fecthall() returns empty list if no results
listOfResults=c.fetchall()
printAll(listOfResults)


# save (commit) the changes
conn.commit()

# close the connection and free all resources
conn.close()

